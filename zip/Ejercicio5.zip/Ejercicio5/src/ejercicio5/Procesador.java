/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio5;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.HashMap;


/**
 *
 * @author johanna
 */
public class Procesador extends Thread{
    // Referencia a un socket para enviar/recibir las peticiones/respuestas
	private Socket socketServicio;
	// stream de lectura (por aquí se recibe lo que envía el cliente)
	private InputStream inputStream;
	// stream de escritura (por aquí se envía los datos al cliente)
	private OutputStream outputStream;
	
        // Constructor que tiene como parámetro una referencia al socket abierto en por otra clase
	public Procesador(Socket socketServicio) {
		this.socketServicio=socketServicio;
	
	}
        
        // Aquí es donde se realiza el procesamiento realmente:
        @Override
	public void run(){
		Command command;
		// Como máximo leeremos un bloque de 1024 bytes. Esto se puede modificar.
		String datosRecibido;
                String usuario;
		int bytesRecibidos=0;
		int option, correcto = 1;
		// Array de bytes para enviar la respuesta. Podemos reservar memoria cuando vayamos a enviarka:
		byte [] datosEnviar;
		
		
		try {
                    // Obtiene los flujos de escritura/lectura
			PrintWriter outPrinter = new PrintWriter(socketServicio.getOutputStream(),true);
			BufferedReader inReader = new BufferedReader(new InputStreamReader(socketServicio.getInputStream()));
			
                        
			//Mostramos el menu
			do{
                            outPrinter.println("Menu de opciones: (1)Registrarse (2)Encriptar (3)Desencriptar (-1)Salir");
                             datosRecibido = inReader.readLine();
                             option = Integer.parseInt(datosRecibido);
                             
                             
                                  
                        switch(option){
                            case 1:
                               
                                do{
                                    if(correcto == 1)
                                      outPrinter.println("OK");
                                    else
                                      outPrinter.println("ERROR");
                                    
                                    outPrinter.println("Introduzca el login que quiere:");
                                    usuario = inReader.readLine();
                                   
                                    correcto = usuarioValido(usuario);
                                }while(correcto != 1);
                                
                                outPrinter.println("OK");
                                outPrinter.println("Introduzca el password:");
                                datosRecibido = inReader.readLine();
                                registrar(usuario, datosRecibido);
                                outPrinter.println("REGOK");
                                
                            break;
                            
                            case 2:                                
                                do{
                                    if(correcto == 1)
                                      outPrinter.println("OK");
                                    else
                                      outPrinter.println("ERROR");
                                    
                                    outPrinter.println("Introduzca el usuario al que le quiere enviar el mensaje encriptado:");
                                    usuario = inReader.readLine(); 
                                    correcto = usuarioExistente(usuario);
                                }while(correcto != 1);
                                
                                outPrinter.println("OK");
                                outPrinter.println("Introduzca el mensaje que le quiere encriptar:");
                                datosRecibido = inReader.readLine();
                                String mensaje = encriptar(usuario,datosRecibido);
                                outPrinter.println(mensaje);
                                
                            break;
                            
                            case 3:
                            
                                do{
                                    if(correcto == 1)
                                      outPrinter.println("OK");
                                    else
                                      outPrinter.println("ERROR");
                                    
                                    outPrinter.println("Introduzca su login y su passwd para desencriptar el mensaje:");
                                    datosRecibido = inReader.readLine();
                                    
                                    correcto = loginCorrecto(datosRecibido);
                                }while(correcto != 1);
                                
                                outPrinter.println("OK");
                                outPrinter.println("Introduzca el mensaje que le quiere desencriptar:");
                                datosRecibido = inReader.readLine();
                                mensaje = desencriptar(datosRecibido);
                                outPrinter.println(mensaje);
                                    
                            break;
                            
                            default:
                                option = -1;
                        }
                        
                        
                        }while(option != -1);
                        
                        
                  
                        outPrinter.println("-1");
			// Yoda hace su magia:
			// Creamos un String a partir de un array de bytes de tamaño "bytesRecibidos":
			
			// Yoda reinterpreta el mensaje:
			//String respuesta=yodaDo(datosRecibido);
			// Convertimos el String de respuesta en una array de bytes:
			
			// Enviamos la traducción de Yoda:
			////////////////////////////////////////////////////////
	//		outPrinter.println(respuesta);
			////////////////////////////////////////////////////////
			
			
			
		} catch (IOException e) {
			System.err.println("Error al obtener los flujso de entrada/salida.");
		}

	}

  
        private int usuarioValido(String login){
            if(login.equals("johanna"))
                return 0;
            else
                return 1;
        }
     
        private String encriptar(String usuario, String mensaje){
            return "Hola";
        }
        
        private String desencriptar(String mensaje){
            return "bad";
        }
        
        private void registrar(String login, String passwd){
            
        }
        
        private int usuarioExistente(String login){
            return 1;
        }
        
        private int loginCorrecto(String login){
            if(login.equals("johanna*ajedrez"))
                return 1;
            else return 0;
        }
}
