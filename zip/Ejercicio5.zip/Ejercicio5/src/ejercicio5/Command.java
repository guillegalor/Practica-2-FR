package ejercicio5;

/**
 *
 * @author johanna
 */
public enum Command {
  Exit (0, "Salir"),
  Login (1, "Login"), 
  Encrypt (2, "Encriptar"),
  Decrypt (3, "Desencriptar"), 
  Other (4, "Otra consulta"); 
    
  public final int menu;
  public final String text;
  
  private Command (int aValue, String aText) {
    this.menu = aValue;
    this.text = aText;
  }
}
